Hook.Add("chatMessage", "VoiceControl_AllBotsFollowPlayer", function(message, client)
    if message == "пуск" then
        local player = client.Character
        if player == nil then
            print("❌ Игрок не имеет персонажа.")
            return
        end

        -- Получаем prefab приказа "follow"
        local orderPrefab = OrderPrefab.Prefabs["follow"]
        if orderPrefab == nil then
            print("❌ OrderPrefab 'follow' не найден!")
            return
        end

        local botsFound = false

        -- Проходимся по всем ботам
        for _, bot in pairs(Character.CharacterList) do
            if bot.IsBot and not bot.IsDead then
                botsFound = true

                -- Создаём приказ следовать за игроком
                local baseOrder = Order(orderPrefab, player, nil, player)

                -- Устанавливаем приоритет приказа
                local order = baseOrder:WithManualPriority(100)

                -- Добавляем приказ боту
                if bot.SetOrder then
                    bot:SetOrder(order, true)
                elseif bot.AIController and bot.AIController.SetOrder then
                    bot.AIController:SetOrder(order, true)
                else
                    print("❌ Не удалось выдать приказ для " .. bot.Name .. " — методы недоступны.")
                end

                print("🤖 " .. bot.Name .. " теперь следует за игроком " .. player.Name .. " (приоритет = 100)")
            end
        end

        if not botsFound then
            print("❌ Ни один бот не найден.")
        end
    end
end)
